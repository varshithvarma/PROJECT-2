import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:taskeet/Tasks/all_tasks.dart';
import 'package:taskeet/calender.dart';
import 'package:taskeet/Tasks/completed.dart';
import 'package:taskeet/drawer.dart';
import 'package:taskeet/hamepage.dart';
import 'package:taskeet/Tasks/overdue.dart';
import 'package:taskeet/Tasks/todaystasks.dart';
import 'package:taskeet/home.dart';
import 'package:taskeet/todos.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) => ChangeNotifierProvider(
        create: (context) => TodosProvider(),
        child: MaterialApp(
          title: 'flutter authen',
          debugShowCheckedModeBanner: false,
          home: const Homepage(),
          routes: {
            'homepage': (context) => const Homepage(),
            'calender': (context) => const Calender(),
            'completed': (context) => const Completed(),
            'overdue': (context) => const Overdue(),
            'todaystasks': (context) => const Todaystasks(),
            'alltasks': (context) => const Alltasks(),
            'drawer': (context) => const Drawerr(),
            'home': (context) => const Home(),
          },
        ),
      );
}
