// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:flutter/material.dart';

// class Floatactbutton extends StatefulWidget {
//   const Floatactbutton({Key? key}) : super(key: key);

//   @override
//   _FloatactbuttonState createState() => _FloatactbuttonState();
// }

// class _FloatactbuttonState extends State<Floatactbutton> {
//   late Map data;
//   final db = FirebaseFirestore.instance;
//   late String task;
//   void showdialog() {
//     GlobalKey<FormState> formkey = GlobalKey<FormState>();
//     showDialog(
//         context: context,
//         builder: (context) {
//           return AlertDialog(
//             title: const Text("Add Todo"),
//             content: Form(
//               key: formkey,
//               autovalidate: true,
//               child: TextFormField(
//                 autofocus: true,
//                 decoration: const InputDecoration(
//                   border: OutlineInputBorder(),
//                   labelText: "Task",
//                 ),
//                 validator: (_val) {
//                   if (_val!.isEmpty) {
//                     return "Cant be empty";
//                   } else {
//                     return null;
//                   }
//                 },
//                 onChanged: (_val) {
//                   task = _val;
//                 },
//               ),
//             ),
//             actions: [
//               RaisedButton(
//                 onPressed: () {
//                   db.collection('tsak').add({'task': task});
//                   Navigator.pop(context);
//                 },
//                 child: const Text(
//                   'ADD',
//                 ),
//               )
//             ],
//           );
//         });
//   }

//   Widget build(BuildContext context) {
//     return FloatingActionButton(
//       backgroundColor: Colors.purpleAccent,
//       splashColor: Colors.lightGreenAccent,
//       onPressed: showdialog,
//       child: const Icon(Icons.add),
//     );
//   }
// }
