import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:taskeet/add_todo_dialog.dart';
import 'package:taskeet/drawer.dart';
import 'package:taskeet/floatingact_button.dart';
import 'package:taskeet/todo_list_widget.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  final db = FirebaseFirestore.instance;
  late String task;
  void showdialog() {
    GlobalKey<FormState> formkey = GlobalKey<FormState>();
    showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text("Add Todo"),
            content: Form(
              key: formkey,
              autovalidate: true,
              child: TextFormField(
                autofocus: true,
                decoration: const InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Task",
                ),
                validator: (_val) {
                  if (_val!.isEmpty) {
                    return "Cant be empty";
                  } else {
                    return null;
                  }
                },
                onChanged: (_val) {
                  task = _val;
                },
              ),
            ),
            actions: [
              RaisedButton(
                onPressed: () {
                  db.collection('tsak').add({'task': task});
                  Navigator.pop(context);
                },
                child: const Text(
                  'ADD',
                ),
              )
            ],
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purpleAccent,
        centerTitle: true,
        title: const Text(
          'Tasks       ',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: Icon(Icons.search),
          )
        ],
      ),
      // body: Column(children: [
      //   Padding(
      //     padding: const EdgeInsets.all(8.0),
      //     child: Container(
      //       height: 35,
      //       width: MediaQuery.of(context).size.width,
      //       decoration: BoxDecoration(
      //         border: Border.all(
      //           color: Colors.black,
      //         ),
      //         borderRadius: BorderRadius.circular(10),
      //       ),
      //       margin: const EdgeInsets.only(bottom: 30, left: 15, right: 15),
      //       child: Row(
      //         children: [
      //           const Text(
      //             "   My Tasks !",
      //             style: TextStyle(
      //               fontSize: 20,
      //               letterSpacing: 1.3,
      //               fontWeight: FontWeight.bold,
      //             ),
      //           ),
      //           SizedBox(width: 60),
      //           DropdownButton<String>(
      //             items: [
      //               DropdownMenuItem<String>(
      //                 value: 'All Tasks',
      //                 child: Center(
      //                   child: InkWell(
      //                     onTap: () {
      //                       Navigator.pushNamed(context, 'alltasks');
      //                     },
      //                     child: Text(
      //                       'All Tasks',
      //                       style: TextStyle(
      //                         fontWeight: FontWeight.bold,
      //                       ),
      //                     ),
      //                   ),
      //                 ),
      //               ),
      //               DropdownMenuItem<String>(
      //                 value: 'Todays tasks',
      //                 child: Center(
      //                   child: InkWell(
      //                     onTap: () {
      //                       Navigator.pushNamed(context, 'todaystasks');
      //                     },
      //                     child: Text(
      //                       'Todays tasks',
      //                       style: TextStyle(
      //                         fontWeight: FontWeight.bold,
      //                       ),
      //                     ),
      //                   ),
      //                 ),
      //               ),
      //               DropdownMenuItem<String>(
      //                 value: 'OverDue Tasks',
      //                 child: Center(
      //                   child: InkWell(
      //                     onTap: () {
      //                       Navigator.pushNamed(context, 'overdue');
      //                     },
      //                     child: Text(
      //                       'OverDue Tasks ',
      //                       style: TextStyle(
      //                         fontWeight: FontWeight.bold,
      //                       ),
      //                     ),
      //                   ),
      //                 ),
      //               ),
      //               DropdownMenuItem<String>(
      //                 value: 'completed Tasks',
      //                 child: Center(
      //                   child: InkWell(
      //                     onTap: () {
      //                       Navigator.pushNamed(context, 'completed');
      //                     },
      //                     child: Text(
      //                       'completed Tasks',
      //                       style: TextStyle(
      //                         fontWeight: FontWeight.bold,
      //                       ),
      //                     ),
      //                   ),
      //                 ),
      //               ),
      //             ],
      //             onChanged: (_value) {
      //               setState(() {
      //                 var value = _value;
      //               });
      //             },
      //           ),
      //         ],
      //       ),
      //     ),
      //   ),
      //   const SizedBox(height: 20),
      body: TodoListwidget(),

      floatingActionButton: FloatingActionButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: Colors.black,
        onPressed: () => showDialog(
          context: context,
          builder: (context) => AddTodoDialogWidget(),
          barrierDismissible: false,
        ),
        child: Icon(Icons.add),
      ),
      drawer: const Drawerr(),
    );
  }
}
























// ListView(
//         children: [
//           const SizedBox(height: 20),
//           Column(children: [
//             Padding(
//               padding: const EdgeInsets.all(8.0),
//               child: Container(
//                 height: 35,
//                 width: MediaQuery.of(context).size.width,
//                 decoration: BoxDecoration(
//                   border: Border.all(
//                     color: Colors.black,
//                   ),
//                   borderRadius: BorderRadius.circular(10),
//                 ),
//                 margin: const EdgeInsets.only(bottom: 30, left: 15, right: 15),
//                 child: Row(
//                   children: [
//                     const Text(
//                       "   My Tasks !",
//                       style: TextStyle(
//                         fontSize: 20,
//                         letterSpacing: 1.3,
//                         fontWeight: FontWeight.bold,
//                       ),
//                     ),
//                     SizedBox(width: 60),
//                     DropdownButton<String>(
//                       items: [
//                         DropdownMenuItem<String>(
//                           value: 'All Tasks',
//                           child: Center(
//                             child: InkWell(
//                               onTap: () {
//                                 Navigator.pushNamed(context, 'alltasks');
//                               },
//                               child: Text(
//                                 'All Tasks',
//                                 style: TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                         DropdownMenuItem<String>(
//                           value: 'Todays tasks',
//                           child: Center(
//                             child: InkWell(
//                               onTap: () {
//                                 Navigator.pushNamed(context, 'todaystasks');
//                               },
//                               child: Text(
//                                 'Todays tasks',
//                                 style: TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                         DropdownMenuItem<String>(
//                           value: 'OverDue Tasks',
//                           child: Center(
//                             child: InkWell(
//                               onTap: () {
//                                 Navigator.pushNamed(context, 'overdue');
//                               },
//                               child: Text(
//                                 'OverDue Tasks ',
//                                 style: TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                         DropdownMenuItem<String>(
//                           value: 'completed Tasks',
//                           child: Center(
//                             child: InkWell(
//                               onTap: () {
//                                 Navigator.pushNamed(context, 'completed');
//                               },
//                               child: Text(
//                                 'completed Tasks',
//                                 style: TextStyle(
//                                   fontWeight: FontWeight.bold,
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ],
//                       onChanged: (_value) {
//                         setState(() {
//                           value = _value!;
//                         });
//                       },
//                     ),
//                   ],
//                 ),
//               ),
//             ),
// //             const SizedBox(height: 20),
//   body: StreamBuilder<QuerySnapshot>(
//           stream: db.collection('tasks').snapshots(),
//           builder: (context, snapshot) {
//             if (snapshot.hasData) {
//               return ListView.builder(
//                   itemCount: (snapshot.data!).docs.length,
//                   itemBuilder: (context, index) {
//                     DocumentSnapshot ds = (snapshot.data!).docs[index];
//                     return ListTile(
//                       title: Text(
//                         'task',
//                       ),
//                     );
//                   });
//             } else {
//               return const CircularProgressIndicator();
//             }
//           }),
//           ]),
//         ],
//       ),