import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:taskeet/Todo_Widgets/TodoWidget.dart';
import 'package:taskeet/Todo_Widgets/todos.dart';

class TodoListwidget extends StatelessWidget {
  const TodoListwidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TodosProvider>(context);

    final todos = provider.todos;

    return todos.isEmpty
        ? SingleChildScrollView(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(height: 220),
                    const Icon(
                      Icons.credit_card_off_outlined,
                      size: 50,
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "No tasks",
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 240),
                    Row(
                      children: const [
                        Text(
                          'ADD TASK ',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Icon(
                          Icons.arrow_right_alt_sharp,
                          size: 50,
                        ),
                      ],
                    )
                  ],
                ),
              ],
            ),
          )
        : ListView.separated(
            padding: const EdgeInsets.all(16),
            physics: const BouncingScrollPhysics(),
            separatorBuilder: (context, index) => Container(height: 20),
            itemBuilder: (context, index) {
              final todo = todos[index];
              return TodoWidget(todo: todo);
            },
            itemCount: todos.length,
          );
  }
}
