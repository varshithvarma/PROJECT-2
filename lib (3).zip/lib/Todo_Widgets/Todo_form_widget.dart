// ignore_for_file: avoid_print, file_names, prefer_const_constructors, prefer_const_constructors_in_immutables

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TodoFormWidget extends StatefulWidget {
  final String title;

  final ValueChanged<String> onChangedTitle;

  final VoidCallback onSavedTodo;

  TodoFormWidget({
    Key? key,
    this.title = '',
    required this.onChangedTitle,
    required this.onSavedTodo,
  }) : super(key: key);

  @override
  State<TodoFormWidget> createState() => _TodoFormWidgetState();
}

class _TodoFormWidgetState extends State<TodoFormWidget> {
  DateTime mydate = DateTime.now();
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            buildTitle(),
            SizedBox(height: 30),
            buildButton(),
          ],
        ),
      );

  Widget buildTitle() => TextFormField(
        maxLines: 1,
        initialValue: widget.title,
        onChanged: widget.onChangedTitle,
        validator: (title) {
          if (title!.isEmpty) {
            return 'The title cannot be empty';
          }
          return null;
        },
        decoration: InputDecoration(
          border: const UnderlineInputBorder(),
          labelText: 'Title',
        ),
      );

  Widget builddate() => IconButton(
        icon: Icon(Icons.calendar_today_outlined),
        onPressed: () async {
          DateTime? pickerdate = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(2010),
              lastDate: DateTime(2030));
          if (pickerdate != null) {
            setState(() {
              mydate = pickerdate;
            });
          } else {
            print('something wrong');
          }
        },
      );
  Widget builddatetext() => TextFormField(
        maxLines: 1,
        readOnly: false,
        initialValue: DateFormat.yMd().format(mydate),
        decoration: InputDecoration(
          border: const UnderlineInputBorder(),
          labelText: 'Date',
        ),
      );

  Widget buildButton() => SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.black),
          ),
          onPressed: widget.onSavedTodo,
          child: Text('Save'),
        ),
      );
}
