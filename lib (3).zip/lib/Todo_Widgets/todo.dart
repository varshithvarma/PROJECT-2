import '../utils.dart';

class TodoField {
  static const createdTime = 'createdTime';
}

class Todo {
  DateTime createdTime;

  String title;
  String id;
  late bool isDone;
  // String date;

  Todo({
    required this.createdTime,
    required this.title,
    required this.id,
    // required this.date,
    this.isDone = false,
  });

  static Todo fromJson(Map<String, dynamic> json) => Todo(
        createdTime: Utils.toDateTime(json['createdTime']),
        title: json['title'],
        id: json['id'],
        isDone: json['isDone'],
        // date: json['date'],
      );

  Map<String, dynamic> toJson() => {
        'createdTime': Utils.fromDateTimeToJson(createdTime),
        'title': title,
        'id': id,
        'isDone': isDone,
        // 'date': date,
      };
}
