import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:taskeet/pages/login.dart';
import 'package:taskeet/pages/usermodel.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    return const Account();
  }
}

class Account extends StatefulWidget {
  const Account({Key? key}) : super(key: key);

  @override
  _AccountState createState() => _AccountState();
}

class _AccountState extends State<Account> {
  User? user = FirebaseAuth.instance.currentUser;
  UserMain loggedInUser = UserMain();

  @override
  void initState() {
    super.initState();
    FirebaseFirestore.instance
        .collection("users")
        .doc(user!.uid)
        .get()
        .then((value) {
      loggedInUser = UserMain.fromMap(value.data());
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "Profile",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
        backgroundColor: Colors.deepPurpleAccent,
        centerTitle: true,
        leading: IconButton(
            onPressed: () => {Navigator.pop(context)},
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white)),
      ),
      body: Padding(
        padding: const EdgeInsets.fromLTRB(10.0, 0, 10.0, 0),
        child: ListView(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                const Padding(
                    padding: EdgeInsets.only(left: 0.0, right: 15.0, top: 15),
                    child: Icon(Icons.person, size: 80)),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      const SizedBox(height: 10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(
                            "${loggedInUser.firstName} ",
                            style: const TextStyle(
                              fontSize: 26.0,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.3,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 5.0),
                      // Row(
                      //   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //   children:  <Widget>[
                      //     Text(
                      //       "${loggedInUser.email}",
                      //       style: TextStyle(
                      //         fontSize: 16.0,
                      //         fontWeight: FontWeight.bold,
                      //         fontFamily: 'Cookie',
                      //         letterSpacing: 1.3,
                      //       ),
                      //     ),
                      //   ],
                      // ),
                      // SizedBox(height: 8.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          InkWell(
                            onTap: () => {
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  content: Form(
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          '          LOGOUT !',
                                          style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: 22,
                                              color: Colors.deepPurpleAccent),
                                        ),
                                        SizedBox(height: 10),
                                        const Text(
                                          'Are  you sure want to logout ? ',
                                          style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        SizedBox(height: 40),
                                        Row(
                                          children: [
                                            SizedBox(width: 15),
                                            InkWell(
                                              onTap: () =>
                                                  {Navigator.pop(context)},
                                              child: Container(
                                                height: 30,
                                                width: 60,
                                                child: const Center(
                                                    child: Text('cancel')),
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                    color: Colors.black,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 100),
                                            InkWell(
                                              onTap: () {
                                                Navigator.pushReplacement(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            const LoginPage()));
                                              },
                                              child: Container(
                                                height: 30,
                                                width: 40,
                                                child:
                                                    Center(child: Text('Ok')),
                                                decoration: BoxDecoration(
                                                  border: Border.all(
                                                    color: Colors.black,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                              ),
                                            )
                                          ],
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                                barrierDismissible: false,
                              ),
                            },
                            child: const Text(
                              "Logout",
                              style: TextStyle(
                                fontSize: 16.0,
                                fontWeight: FontWeight.w400,
                                color: Colors.blue,
                                fontFamily: 'Cookie',
                                letterSpacing: 1.3,
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  flex: 3,
                ),
              ],
            ),
            const Divider(
              thickness: 5,
            ),
            Container(height: 15.0),
            Padding(
              padding: const EdgeInsets.only(
                  right: 5, left: 15.0, top: 5.0, bottom: 5.0),
              child: Text(
                "Account Information".toUpperCase(),
                style: const TextStyle(
                  fontSize: 20.0,
                  fontFamily: 'Cookie',
                  color: Colors.deepPurpleAccent,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.3,
                ),
              ),
            ),
            AccountInfoTable(
              "Full Name",
              "${loggedInUser.firstName} ${loggedInUser.secondName}",
            ),
            const Divider(
              thickness: 1,
              height: 3,
            ),
            AccountInfoTable("Email", "${loggedInUser.email}"),
            const Divider(
              thickness: 1,
              height: 3,
            ),
            // AccountInfoTable("Gender", "Prefer Not to Say"),
          ],
        ),
      ),
    );
  }

  // ignore: non_constant_identifier_names
  ListTile AccountInfoTable(text, subtitle) {
    return ListTile(
      title: Text(
        text,
        style: const TextStyle(
          fontSize: 15,
          // fontWeight: FontWeight.w700,
          color: Colors.grey,
          letterSpacing: 1.3,
        ),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.bold,
          color: Colors.black,
          letterSpacing: 1.3,
        ),
      ),
    );
  }
}
