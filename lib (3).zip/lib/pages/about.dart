import 'package:package_info_plus/package_info_plus.dart';
import 'package:flutter/material.dart';

class AboutUsPage extends StatefulWidget {
  const AboutUsPage({Key? key}) : super(key: key);

  @override
  _AboutUsPageState createState() => _AboutUsPageState();
}

class _AboutUsPageState extends State<AboutUsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurpleAccent,
        title: const Text(
          "About Us",
          style: TextStyle(color: Colors.white),
        ),
        centerTitle: true,
        leading: IconButton(
            onPressed: () => {Navigator.pop(context)},
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white)),
      ),
      body: Container(
        margin: const EdgeInsets.only(left: 0.1, right: 0.1, top: 10),
        child: ListView(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: const EdgeInsets.only(left: 5, right: 5, top: 40),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Image.asset(
                        "assets/office.png",
                        height: 120,
                        width: 120,
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "24x7",
                        style: TextStyle(
                            // decoration:TextDecoration.underline,
                            // decorationColor:Colors.black,
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Cookie',
                            color: Colors.black),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        "Task Remainder v1.0.1",
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w600,
                            fontFamily: 'Cookie',
                            color: Colors.deepPurpleAccent),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        "Stay Organized. Stay Focused.",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.normal,
                          color: Colors.black45,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Divider(
                        height: 10,
                        color: Colors.black,
                        thickness: 2,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
            const SizedBox(height: 10),
            // Container(
            //   margin: const EdgeInsets.only(left: 15, right: 20, top: 20),
            //   child: const Text(
            //     "contact@24x7.in.",
            //     style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20,),
            //     textAlign: TextAlign.center,
            //   ),

            // ),

            const SizedBox(height: 20),
            const SizedBox(height: 10),
            // ListTile(
            //   enabled: false,
            //   title: Text("Version"),
            //   trailing: FutureBuilder(
            //     future: getVersionNumber(),
            //     builder: (BuildContext
            //     context,AsyncSnapshot<String>snapshot) =>
            //         Text(
            //           snapshot.hasData ? snapshot.data:Platform.version,
            //           style: TextStyle(
            //             color: Colors.grey,
            //           ),),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  getVersion() {
    PackageInfo.fromPlatform().then((PackageInfo packageInfo) {
      // ignore: non_constant_identifier_names
      String Version = packageInfo.version;
      return Version;
    });
  }
}
