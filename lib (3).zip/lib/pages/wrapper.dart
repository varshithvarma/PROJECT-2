import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:taskeet/pages/hamepage.dart';
import 'package:taskeet/pages/login.dart';

class WrapperPage extends StatefulWidget {
  const WrapperPage({Key? key}) : super(key: key);

  @override
  _WrapperPageState createState() => _WrapperPageState();
}

class _WrapperPageState extends State<WrapperPage> {
  @override
  Widget build(BuildContext context) {
    final _auth = FirebaseAuth.instance;
    User? curuser = _auth.currentUser;

    _auth.userChanges().listen((User? user) {
      curuser = user;
    });
    if (curuser == null) {
      return const LoginPage();
    } else {
      return const Homepage();
    }
  }
}
