// ignore_for_file: deprecated_member_use, duplicate_ignore, prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:settings_ui/settings_ui.dart';
import 'package:taskeet/pages/about.dart';
import 'package:taskeet/pages/login.dart';
import 'package:taskeet/pages/privacy.dart';
import 'package:taskeet/pages/profile.dart';
import 'package:taskeet/pages/terms_conditions.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsPage> {
  bool lockInBackground = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: Center(
        child: SettingsList(
          sections: [
            SettingsSection(
              title: 'Account',
              tiles: [
                //SettingsTile(title: 'Phone number', leading: Icon(Icons.phone)),
                SettingsTile(
                  title: 'Account Information',
                  leading: const Icon(Icons.account_circle_outlined),
                  // ignore: deprecated_member_use
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const ProfilePage()));
                    showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (BuildContext context) {
                          Future.delayed(const Duration(seconds: 1), () {
                            Navigator.of(context).pop(true);
                          });
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        });
                  },
                ),
                SettingsTile(
                  title: 'Sign out',
                  leading: const Icon(Icons.exit_to_app),
                  // ignore: deprecated_member_use
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (context) => AlertDialog(
                        content: Form(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                '          LOGOUT !',
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 22,
                                    color: Colors.deepPurpleAccent),
                              ),
                              SizedBox(height: 10),
                              const Text(
                                'Are  you sure want to logout ? ',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(height: 40),
                              Row(
                                children: [
                                  SizedBox(width: 15),
                                  InkWell(
                                    onTap: () => {Navigator.pop(context)},
                                    child: Container(
                                      height: 30,
                                      width: 60,
                                      child:
                                          const Center(child: Text('cancel')),
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.black,
                                        ),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 100),
                                  InkWell(
                                    onTap: () {
                                      Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  const LoginPage()));
                                    },
                                    child: Container(
                                      height: 30,
                                      width: 40,
                                      child: Center(child: Text('Ok')),
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                          color: Colors.black,
                                        ),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                      barrierDismissible: false,
                    );
                  },
                ),
              ],
            ),
            SettingsSection(
              title: 'Notifications',
              tiles: [
                SettingsTile(
                  title: 'Notification Preferences',
                  leading: const Icon(Icons.notifications_none_outlined),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Appearance',
              tiles: [
                SettingsTile(
                  title: 'Theme',
                  leading: Icon(Icons.brush),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Security',
              tiles: [
                // SettingsTile.switchTile(
                //   title: 'Lock app in background',
                //   leading: Icon(Icons.phonelink_lock),
                //   switchValue: lockInBackground,
                //   onToggle: (bool value) {
                //     setState(() {
                //       lockInBackground = value;
                //     });
                //   },
                // ),
                SettingsTile(
                  title: 'Change Email',
                  leading: Icon(Icons.email_outlined),
                  onTap: () {},
                ),
                SettingsTile(
                  title: 'Change Password',
                  leading: Icon(Icons.vpn_key_outlined),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Help',
              tiles: [
                //SettingsTile(title: 'Phone number', leading: Icon(Icons.phone)),
                SettingsTile(
                  title: 'Feedback',
                  leading: Icon(Icons.question_answer_outlined),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Misc',
              tiles: [
                SettingsTile(
                  title: 'Terms of Service',
                  leading: Icon(Icons.description_outlined),
                  onPressed: (context) {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => TermsPage()));
                  },
                ),
                SettingsTile(
                  title: 'Privacy Policy',
                  leading: Icon(Icons.privacy_tip_outlined),
                  onPressed: (context) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PrivacyPolicyPage()));
                  },
                ),
                SettingsTile(
                  title: 'About',
                  leading: Icon(Icons.info_outline),
                  onPressed: (context) {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => AboutUsPage()));
                  },
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
