class UserMain {
  String? uid;
  String? email;
  String? firstName;
  String? secondName;

  UserMain({this.uid, this.email, this.firstName, this.secondName});

  //data from server

  // send data to server
  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'firstName': firstName,
      'secondName': secondName,
    };
  }

  factory UserMain.fromMap(map) {
    return UserMain(
      uid: map['uid'],
      email: map['email'],
      firstName: map['firstName'],
      secondName: map['secondName'],
    );
  }
}
