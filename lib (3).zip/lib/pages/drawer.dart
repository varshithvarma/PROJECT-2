import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class Drawerr extends StatefulWidget {
  const Drawerr({Key? key}) : super(key: key);

  @override
  _DrawerState createState() => _DrawerState();
}

class _DrawerState extends State<Drawerr> {
  @override
  Widget build(BuildContext context) {
    String uid = FirebaseAuth.instance.currentUser!.uid;
    return Drawer(
      child: ListView(
        children: [
          StreamBuilder<DocumentSnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('users')
                  .doc(uid)
                  .snapshots(),
              builder: (BuildContext context, AsyncSnapshot snapshot) {
                if (snapshot.hasData) {
                  var data = snapshot.requireData;
                  return UserAccountsDrawerHeader(
                    accountName: Text(
                      data['firstName'],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                      ),
                    ),
                    accountEmail: Text(
                      data['email'],
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    currentAccountPicture: GestureDetector(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          CircleAvatar(
                            radius: 35,
                            backgroundColor: Colors.white,
                            child: Icon(
                              Icons.person,
                              color: Colors.deepPurpleAccent,
                              size: 50.0,
                            ),
                          ),
                        ],
                      ),
                    ),
                    decoration:
                        const BoxDecoration(color: Colors.deepPurpleAccent),
                  );
                } else {
                  return const Center(
                    child: CircularProgressIndicator(
                      color: Colors.black,
                    ),
                  );
                }
              }),
          InkWell(
            onTap: () => {Navigator.pop(context)},
            child: const ListTile(
              title: Text(
                'Home',
                style: TextStyle(
                  letterSpacing: 1.0,
                  fontSize: 18.0,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              leading: Icon(
                Icons.home,
                color: Colors.black,
              ),
            ),
          ),
          InkWell(
            onTap: () => {Navigator.pushNamed(context, 'profile')},
            child: const ListTile(
              title: Text(
                'profile',
                style: TextStyle(
                  fontSize: 18.0,
                  letterSpacing: 1.3,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              leading: Icon(
                Icons.person_outline_outlined,
                color: Colors.black,
              ),
            ),
          ),
          InkWell(
            onTap: () => {Navigator.pushNamed(context, 'privacy')},
            child: const ListTile(
              title: Text(
                'privacy policy',
                style: TextStyle(
                  fontSize: 18.0,
                  letterSpacing: 1.3,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              leading: Icon(
                Icons.privacy_tip_outlined,
                color: Colors.black,
              ),
            ),
          ),
          InkWell(
            onTap: () => {Navigator.pushNamed(context, 'settings')},
            child: const ListTile(
              title: Text(
                'Settings',
                style: TextStyle(
                  fontSize: 18.0,
                  letterSpacing: 1.3,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              leading: Icon(
                Icons.settings,
                color: Colors.black,
              ),
            ),
          ),
          InkWell(
            onTap: () => {Navigator.pushNamed(context, 'aboutus')},
            child: const ListTile(
              title: Text(
                'About us',
                style: TextStyle(
                  fontSize: 18.0,
                  letterSpacing: 1.3,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              leading: Icon(
                Icons.help,
                color: Colors.black,
              ),
            ),
          ),
          InkWell(
            onTap: () => {Navigator.pushNamed(context, 'terms')},
            child: const ListTile(
              title: Text(
                'Terms & Conditions',
                style: TextStyle(
                  fontSize: 18.0,
                  letterSpacing: 1.3,
                  fontWeight: FontWeight.w600,
                  color: Colors.black,
                ),
              ),
              leading: Icon(
                Icons.file_copy,
                color: Colors.black,
              ),
            ),
          ),
          const Divider(
            height: 30,
          ),
          const InkWell(
            child: ListTile(
              title: Text(
                "Version : 2.0.9",
                style: TextStyle(
                  fontSize: 18.0,
                  letterSpacing: 1.3,
                  fontWeight: FontWeight.w500,
                  color: Colors.black,
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
