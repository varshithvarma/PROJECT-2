// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:taskeet/Todo_Widgets/completed_list_widget.dart';

class Completed extends StatefulWidget {
  const Completed({Key? key}) : super(key: key);

  @override
  _CompletedState createState() => _CompletedState();
}

class _CompletedState extends State<Completed> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => {Navigator.pushNamed(context, 'homepage')},
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white)),
        backgroundColor: Colors.deepPurpleAccent,
        centerTitle: true,
        title: const Text(
          'completed tasks       ',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: Icon(Icons.search),
          )
        ],
      ),
      body: CompletedListWidget(),
      backgroundColor: Colors.black.withOpacity(.1),
    );
  }
}
