// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

class Overdue extends StatefulWidget {
  const Overdue({Key? key}) : super(key: key);

  @override
  _OverdueState createState() => _OverdueState();
}

class _OverdueState extends State<Overdue> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => {Navigator.pop(context)},
            icon: Icon(Icons.arrow_back_rounded, color: Colors.black)),
        backgroundColor: Colors.purpleAccent,
        centerTitle: true,
        title: const Text(
          'Overdue Tasks       ',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: Icon(Icons.search),
          )
        ],
      ),
    );
  }
}
