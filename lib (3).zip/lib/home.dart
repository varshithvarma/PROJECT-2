import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:taskeet/add_task_dialog.dart';
import 'package:taskeet/pages/drawer.dart';

import 'Todo_Widgets/todo_list_widget.dart';

class Home extends StatefulWidget {
  const Home({Key? key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.deepPurpleAccent,
        centerTitle: true,
        title: const Text(
          'Tasks       ',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: Icon(Icons.search),
          )
        ],
      ),
      // body: ListView(
      //   children: [
      //     const SizedBox(height: 20),
      //     Column(children: [
      //       Padding(
      //         padding: const EdgeInsets.all(8.0),
      //         child: Container(
      //           height: 35,
      //           width: MediaQuery.of(context).size.width,
      //           decoration: BoxDecoration(
      //             border: Border.all(
      //               color: Colors.black,
      //             ),
      //             borderRadius: BorderRadius.circular(10),
      //           ),
      //           margin: const EdgeInsets.only(bottom: 30, left: 15, right: 15),
      //           child: Row(
      //             children: [
      //               const Text(
      //                 "   My Tasks !",
      //                 style: TextStyle(
      //                   fontSize: 20,
      //                   letterSpacing: 1.3,
      //                   fontWeight: FontWeight.bold,
      //                 ),
      //               ),
      //               SizedBox(width: 60),
      //               DropdownButton<String>(
      //                 items: [
      //                   DropdownMenuItem<String>(
      //                     value: 'All Tasks',
      //                     child: Center(
      //                       child: InkWell(
      //                         onTap: () {
      //                           Navigator.pushNamed(context, 'alltasks');
      //                         },
      //                         child: Text(
      //                           'All Tasks',
      //                           style: TextStyle(
      //                             fontWeight: FontWeight.bold,
      //                           ),
      //                         ),
      //                       ),
      //                     ),
      //                   ),
      //                   DropdownMenuItem<String>(
      //                     value: 'Todays tasks',
      //                     child: Center(
      //                       child: InkWell(
      //                         onTap: () {
      //                           Navigator.pushNamed(context, 'todaystasks');
      //                         },
      //                         child: Text(
      //                           'Todays tasks',
      //                           style: TextStyle(
      //                             fontWeight: FontWeight.bold,
      //                           ),
      //                         ),
      //                       ),
      //                     ),
      //                   ),
      //                   DropdownMenuItem<String>(
      //                     value: 'OverDue Tasks',
      //                     child: Center(
      //                       child: InkWell(
      //                         onTap: () {
      //                           Navigator.pushNamed(context, 'overdue');
      //                         },
      //                         child: Text(
      //                           'OverDue Tasks ',
      //                           style: TextStyle(
      //                             fontWeight: FontWeight.bold,
      //                           ),
      //                         ),
      //                       ),
      //                     ),
      //                   ),
      //                   DropdownMenuItem<String>(
      //                     value: 'completed Tasks',
      //                     child: Center(
      //                       child: InkWell(
      //                         onTap: () {
      //                           Navigator.pushNamed(context, 'completed');
      //                         },
      //                         child: Text(
      //                           'completed Tasks',
      //                           style: TextStyle(
      //                             fontWeight: FontWeight.bold,
      //                           ),
      //                         ),
      //                       ),
      //                     ),
      //                   ),
      //                 ],
      //                 onChanged: (_value) {
      //                   setState(() {
      //                     var value = _value!;
      //                   });
      //                 },
      //               ),
      //             ],
      //           ),
      //         ),
      //       ),
      //       Container(
      //         child: TodoListwidget(),
      //         color: Colors.amber,
      //       )
      //     ]),
      //   ],
      // ),
      body: const TodoListwidget(),

      backgroundColor: Colors.black.withOpacity(.1),

      floatingActionButton: FloatingActionButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
        ),
        backgroundColor: Colors.black,
        onPressed: () => showDialog(
          context: context,
          builder: (context) => const AddTodoDialogWidget(),
          barrierDismissible: false,
        ),
        child: const Icon(Icons.add),
      ),
      drawer: const Drawerr(),
    );
  }
}
