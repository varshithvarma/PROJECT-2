import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:taskeet/Todo_Widgets/todo.dart';
import 'package:taskeet/Todo_Widgets/todos.dart';

import '../Firebase_Api.dart';
import 'calender.dart';
import '../Tasks/completed.dart';
import '../home.dart';

class Homepage extends StatefulWidget {
  const Homepage({Key? key}) : super(key: key);

  @override
  _HomepageState createState() => _HomepageState();
}

class _HomepageState extends State<Homepage> {
  int selectedIndex = 1;
  final tabs = [
    const Calender(),
    const Home(),
    const Completed(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   backgroundColor: Colors.purpleAccent,
      //   centerTitle: true,
      //   title: const Text(
      //     'Tasks       ',
      //     style: TextStyle(
      //       color: Colors.black,
      //     ),
      //   ),
      //   actions: const [
      //     Padding(
      //       padding: EdgeInsets.only(right: 20.0),
      //       child: Icon(Icons.search),
      //     )
      //   ],
      // ),
      // drawer: Drawerr(),
      body: StreamBuilder<List<Todo>>(
        stream: FirebaseApi.readTodos(),
        builder: (context, snapshot) {
          switch (snapshot.connectionState) {
            case ConnectionState.waiting:
              return Center(child: CircularProgressIndicator());
            default:
              if (snapshot.hasError) {
                return CircularProgressIndicator();
              } else {
                final todos = snapshot.data;

                final provider = Provider.of<TodosProvider>(context);
                provider.setTodos(todos!);

                return tabs[selectedIndex];
              }
          }
        },
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.deepPurpleAccent,
        unselectedItemColor: Colors.white.withOpacity(0.7),
        selectedItemColor: Colors.white,
        currentIndex: selectedIndex,
        onTap: (index) => setState(() {
          selectedIndex = index;
        }),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_today_outlined),
            label: 'calender',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.credit_score, size: 28),
            label: 'Tasks',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.done_outline_rounded, size: 28),
            label: 'completed',
          ),
        ],
      ),
    );
  }
}
