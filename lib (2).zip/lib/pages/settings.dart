import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:settings_ui/settings_ui.dart';
import 'package:taskeet/pages/about.dart';
import 'package:taskeet/pages/login.dart';
import 'package:taskeet/pages/privacy.dart';
import 'package:taskeet/pages/profile.dart';
import 'package:taskeet/pages/terms_conditions.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsPage> {
  bool lockInBackground = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
        backgroundColor: Colors.deepPurpleAccent,
      ),
      body: Center(
        child: SettingsList(
          sections: [
            SettingsSection(
              title: 'Account',
              tiles: [
                //SettingsTile(title: 'Phone number', leading: Icon(Icons.phone)),
                SettingsTile(
                  title: 'Account Information',
                  leading: Icon(Icons.account_circle_outlined),
                  // ignore: deprecated_member_use
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => ProfilePage()));
                    showDialog(
                        barrierDismissible: false,
                        context: context,
                        builder: (BuildContext context) {
                          Future.delayed(Duration(seconds: 1), () {
                            Navigator.of(context).pop(true);
                          });
                          return Center(
                            child: CircularProgressIndicator(),
                          );
                        });
                  },
                ),
                SettingsTile(
                  title: 'Sign out',
                  leading: Icon(Icons.exit_to_app),
                  // ignore: deprecated_member_use
                  onTap: () {
                    FirebaseAuth.instance.signOut();
                    Navigator.pushReplacement(context,
                        MaterialPageRoute(builder: (context) => LoginPage()));
                  },
                ),
              ],
            ),
            SettingsSection(
              title: 'Notifications',
              tiles: [
                SettingsTile(
                  title: 'Notification Preferences',
                  leading: Icon(Icons.notifications_none_outlined),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Appearance',
              tiles: [
                SettingsTile(
                  title: 'Theme',
                  leading: Icon(Icons.brush),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Security',
              tiles: [
                // SettingsTile.switchTile(
                //   title: 'Lock app in background',
                //   leading: Icon(Icons.phonelink_lock),
                //   switchValue: lockInBackground,
                //   onToggle: (bool value) {
                //     setState(() {
                //       lockInBackground = value;
                //     });
                //   },
                // ),
                SettingsTile(
                  title: 'Change Email',
                  leading: Icon(Icons.email_outlined),
                  onTap: () {},
                ),
                SettingsTile(
                  title: 'Change Password',
                  leading: Icon(Icons.vpn_key_outlined),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Help',
              tiles: [
                //SettingsTile(title: 'Phone number', leading: Icon(Icons.phone)),
                SettingsTile(
                  title: 'Feedback',
                  leading: Icon(Icons.question_answer_outlined),
                  onTap: () {},
                ),
              ],
            ),
            SettingsSection(
              title: 'Misc',
              tiles: [
                SettingsTile(
                  title: 'Terms of Service',
                  leading: Icon(Icons.description_outlined),
                  onPressed: (context) {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => TermsPage()));
                  },
                ),
                SettingsTile(
                  title: 'Privacy Policy',
                  leading: Icon(Icons.privacy_tip_outlined),
                  onPressed: (context) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PrivacyPolicyPage()));
                  },
                ),
                SettingsTile(
                  title: 'About',
                  leading: Icon(Icons.info_outline),
                  onPressed: (context) {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => AboutUsPage()));
                  },
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
