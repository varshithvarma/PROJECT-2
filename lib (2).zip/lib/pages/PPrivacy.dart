class StringConstant2 {
  static const String Welcome =
      "24x7 (“we”, “us”, or “our”) respects the privacy of our users (“user” or “you”). This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our Service. Please read this Privacy Policy carefully. \n   IF YOU DO NOT AGREE WITH THE TERMS OF THIS PRIVACY POLICY, PLEASE DO NOT ACCESS THE APPLICATIONS.";

  static const String Infocoll =
      "We collect several different types of information for various purposes to provide and improve our Service to you.";

  static const String Personaldata =
      "While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (Personal Data). Personally identifiable information may include, but is not limited ";

  static const String Usagedata =
      "When you access the Service by or through a mobile device, we may collect certain information automatically, including,  but not limited to, the type of mobile device you use, your mobile device unique ID, the IP address of your mobile device, your mobile operating system, unique device identifiers and other diagnostic data (Usage Data).";

  static String Cookiesdata =
      "We may use cookies and similar tracking technologies to track the activity on our Service and hold certain information.";

  static String Disclosuredata =
      "We may share information we have collected about you in certain situations. ";

  static String Securritydata =
      "The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.";

  static String Optionsdata =
      "Upon your request to terminate your account, we will deactivate or delete your account and information from our active databases. However, some information may be retained in our files to prevent fraud, troubleshoot problems, assist with any investigations, enforce our Terms of Use and/or comply with legal requirements. If you no longer wish to receive correspondence, emails, or other communications from us, you may opt-out by contacting us using the contact information provided below. If you no longer wish to receive correspondence, emails, or other communications from third parties, you are responsible for contacting the third party directly.";
}
