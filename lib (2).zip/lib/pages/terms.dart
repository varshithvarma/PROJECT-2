class StringConstant1 {
  static const String WELCOME =
      "Thanks for using our products and services. The Services are provided by 24x7. By using our Services, you are agreeing to these terms. Please read them carefully. \n IF YOU DO NOT AGREE TO THESE TERMS, PLEASE DO NOT USE THE SERVICES."
      "These terms govern your use of 24x7's product Task Remainder, including its features, apps, services, technologies, and software we offer, except where we expressly state that separate terms (and not these) apply.";

  static const String USINGOURSERVICE =
      "You must follow any policies made available to you within the Services."
      "Don't misuse our Services. For example, don't interfere with our Services or try to access them using a method other than the interface and the instructions that we provide. You may use our Services only as permitted by law, including applicable export and re-export control laws and regulations. We may suspend or stop providing our Services to you if you do not comply with our terms or policies or if we are investigating suspected misconduct."
      "Using our Services does not give you ownership of any intellectual property rights in our Services or the content you access. You may not use content from our Services unless you obtain permission from its owner or are otherwise permitted by law. These terms do not grant you the right to use any branding or logos used in our Services. Don't remove, obscure, or alter any legal notices displayed in or along with our Services."
      "In connection with your use of the Services, we may send you service announcements, administrative messages, and other information. You may opt out of some of those communications."
      "Most of our Services are available on mobile devices. Do not use such Services in a way that distracts you and prevents you from obeying traffic or safety laws.";

  static const String YOURACC =
      "You may need a 24x7 Account in order to use some of our Services. To protect your 24x7 Account, keep your password confidential. You are responsible for the activity that happens on or through your 24x7 Account. Try not to reuse your 24x7 Account password on third-party applications.";

  static const String PRIVACYCOPY =
      "24x7's Privacy Policy explains how we treat your personal data and protect your privacy when you use our Services. By using our Services, you agree that 24x7 can use such data in accordance with our privacy policies.";

  static const String Yourcontent =
      "Some of our Services allow you to create, upload, submit, save, send or receive content. You retain ownership of any intellectual property rights that you hold in that content. In short, what belongs to you stays yours."
      "You can find more information about how 24x7 uses and stores content in the Privacy Policy or additional terms for particular Services. If you submit feedback or suggestions about our Services, we may use your feedback or suggestions without obligation to you.";

  static const String Ourwarrenties =
      "We provide our Services using a commercially reasonable level of skill and care and we hope that you will enjoy using them. But there are certain things that we don't promise about our Services."
      "OTHER THAN AS EXPRESSLY SET OUT IN THESE TERMS OR ADDITIONAL TERMS, NEITHER 24x7 NOR ITS SUPPLIERS OR DISTRIBUTORS MAKE ANY SPECIFIC PROMISES ABOUT THE SERVICES."
      "SOME JURISDICTIONS PROVIDE FOR CERTAIN WARRANTIES, LIKE THE IMPLIED WARRANTY OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. TO THE EXTENT PERMITTED BY LAW, WE EXCLUDE ALL WARRANTIES.";

  static const String Aboutterms =
      "These terms control the relationship between 24x7 and you. They do not create any third party beneficiary rights. If you do not comply with these terms, and we don't take action right away,"
      "this doesn't mean that we are giving up any rights that we may have such as taking action in the future. If it turns out that a particular term is not enforceable, this will not affect any other terms."
      "\n \n  For more information, please contact us at contact@24x7.in.";
}
