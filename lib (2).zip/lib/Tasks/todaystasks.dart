import 'package:flutter/material.dart';

class Todaystasks extends StatefulWidget {
  const Todaystasks({Key? key}) : super(key: key);

  @override
  _TodaystasksState createState() => _TodaystasksState();
}

class _TodaystasksState extends State<Todaystasks> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => {Navigator.pop(context)},
            icon: Icon(Icons.arrow_back_rounded, color: Colors.black)),
        backgroundColor: Colors.purpleAccent,
        centerTitle: true,
        title: const Text(
          'Todays Tasks       ',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: Icon(Icons.search),
          )
        ],
      ),
    );
  }
}
