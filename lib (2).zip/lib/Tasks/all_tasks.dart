import 'package:flutter/material.dart';

class Alltasks extends StatefulWidget {
  const Alltasks({Key? key}) : super(key: key);

  @override
  _AlltasksState createState() => _AlltasksState();
}

class _AlltasksState extends State<Alltasks> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => {Navigator.pop(context)},
            icon: Icon(Icons.arrow_back_rounded, color: Colors.black)),
        backgroundColor: Colors.purpleAccent,
        centerTitle: true,
        title: const Text(
          'All Tasks       ',
          style: TextStyle(
            color: Colors.black,
          ),
        ),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: Icon(Icons.search),
          )
        ],
      ),
    );
  }
}
