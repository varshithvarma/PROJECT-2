import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:taskeet/Tasks/all_tasks.dart';
import 'package:taskeet/pages/about.dart';
import 'package:taskeet/pages/calender.dart';
import 'package:taskeet/Tasks/completed.dart';
import 'package:taskeet/pages/drawer.dart';
import 'package:taskeet/pages/hamepage.dart';
import 'package:taskeet/Tasks/overdue.dart';
import 'package:taskeet/Tasks/todaystasks.dart';
import 'package:taskeet/home.dart';
import 'package:taskeet/pages/login.dart';
import 'package:taskeet/pages/privacy.dart';
import 'package:taskeet/pages/profile.dart';
import 'package:taskeet/pages/settings.dart';
import 'package:taskeet/pages/signin.dart';
import 'package:taskeet/pages/terms_conditions.dart';

import 'Todo_Widgets/todos.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) => ChangeNotifierProvider(
        create: (context) => TodosProvider(),
        child: MaterialApp(
          title: 'flutter authen',
          debugShowCheckedModeBanner: false,
          home: const LoginPage(),
          routes: {
            'homepage': (context) => const Homepage(),
            'calender': (context) => const Calender(),
            'completed': (context) => const Completed(),
            'overdue': (context) => const Overdue(),
            'todaystasks': (context) => const Todaystasks(),
            'alltasks': (context) => const Alltasks(),
            'drawer': (context) => const Drawerr(),
            'home': (context) => const Home(),
            'settings': (context) => const SettingsPage(),
            'aboutus': (context) => const AboutUsPage(),
            'terms': (context) => const TermsPage(),
            'profile': (context) => const ProfilePage(),
            'privacy': (context) => const PrivacyPolicyPage(),
            'login': (context) => const LoginPage(),
            'signup': (context) => RegisterPage(),
          },
        ),
      );
}
