import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class TodoFormWidget extends StatefulWidget {
  final String title;
  // final String date;
  final ValueChanged<String> onChangedTitle;
  final VoidCallback onSavedTodo;

  TodoFormWidget({
    Key? key,
    this.title = '',
    // this.date = '',
    required this.onChangedTitle,
    required this.onSavedTodo,
  }) : super(key: key);

  @override
  State<TodoFormWidget> createState() => _TodoFormWidgetState();
}

class _TodoFormWidgetState extends State<TodoFormWidget> {
  late DateTime mydate;
  late TimeOfDay mytime;
  String date = ' select a date';
  String time = 'Select a time';

  @override
  void initState() {
    super.initState();

    mydate = DateTime.now();
  }

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            buildTitle(),
            SizedBox(height: 30),
            Text(
              date,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            builddate(),
            SizedBox(height: 15),
            Text(
              'Select a Time',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 15,
              ),
            ),
            buildTime(),
            SizedBox(height: 15),
            buildButton(),
          ],
        ),
      );

  Widget buildTitle() => TextFormField(
        maxLines: 1,
        initialValue: widget.title,
        onChanged: widget.onChangedTitle,
        validator: (title) {
          if (title!.isEmpty) {
            return 'The title cannot be empty';
          }
          return null;
        },
        decoration: InputDecoration(
          border: const UnderlineInputBorder(),
          labelText: 'Title',
        ),
      );

  Widget builddate() => SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.black),
          ),
          onPressed: () async {
            mydate = (await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(DateTime.now().year - 5),
              lastDate: DateTime(DateTime.now().year + 5),
            ))!;
            setState(() {
              date = DateFormat('dd-MM-yyyy').format(mydate);
            });
          },
          child: Text('pick a date'),
        ),
      );

  Widget buildTime() => SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.black),
          ),
          onPressed: () async {
            mytime = (await showTimePicker(
              context: context,
              initialTime: TimeOfDay.now(),
            ))!;
            setState(() {
              time = mytime.toString();
            });
          },
          child: Text('Pick a Time'),
        ),
      );

  Widget buildButton() => SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all(Colors.black),
          ),
          onPressed: widget.onSavedTodo,
          child: Text('Save'),
        ),
      );
}
